1700 candidate/reviewer evidence packet. BLOCKED: comparison evidence is not approval and no production geometry is emitted.
