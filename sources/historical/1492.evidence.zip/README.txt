1492 candidate/reviewer evidence packet. BLOCKED: no rights, factual, topology, reviewer, or production approval is present.
